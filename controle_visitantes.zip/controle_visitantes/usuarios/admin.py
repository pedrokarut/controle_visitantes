from django.contrib import admin
from usuarios.models import Usuario

admin.site.register(Usuario)