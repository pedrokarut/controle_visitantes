from django.shortcuts import render
from visitantes.models import Visitante
#busca info no banco e trabalha com as inter dos usuarios

def index(request):
    
    todos_visitantes = Visitante.objects.all()

    context = {
        #essas variáveis vão lá pro html e podem ser acessadas
        "nome_pagina": "Início da dashboard",
        "todos_visitantes": todos_visitantes
    }
    
    return render(request, "index.html", context)
    #vai renderizar a index.html, o request é obrigatóio
