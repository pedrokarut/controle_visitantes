from django.shortcuts import render
from django.http import HttpResponse
#busca info no banco e trabalha com as inter dos usuarios

def index(request):
    return HttpResponse("Olá mundo")
