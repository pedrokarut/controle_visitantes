from django.contrib import admin
from visitantes.models import Visitante

admin.site.register(Visitante)