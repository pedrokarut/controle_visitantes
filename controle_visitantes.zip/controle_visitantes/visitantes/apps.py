from django.apps import AppConfig


class VisitantesConfig(AppConfig):
    name = 'visitantes'
