from dataclasses import fields
from django import forms
from visitantes.models import Visitante

class VisitanteForm(forms.ModelForm):
    class Meta:
        model = Visitante
        fields = [
            "nome_completo", "cpf", "data_nascimento",
            "numero_casa", "placa_veiculo"
        ]

        error_messages = {
            "nome_completo": {
                "required": "O nome é obrigatório"
            },
            "cpf": {
                "required": "O cpf é obrigatório"
            },
            "data_nascimento": {
                "required": "A data é obrigatória",
                "invalid": "Data inválida (DD/MM/YYYY)"
            },
            "numero_casa": {
                "required": "O num é obrigatória"
            }
        }


class AutorizaVisitanteForm(forms.ModelForm):
    morador_responsavel = forms.CharField(required=True)
    
    class Meta:
        model = Visitante
        fields = [
            "morador_responsavel"
        ]
        error_messages = {
            "morador_responsavel": {
                "required": "Informe o morador responsável pelo visitante"
            }
        }