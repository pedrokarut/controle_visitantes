from django.contrib import admin
from porteiros.models import Porteiro

admin.site.register(Porteiro)