from django.apps import AppConfig


class PorteirosConfig(AppConfig):
    name = 'porteiros'
